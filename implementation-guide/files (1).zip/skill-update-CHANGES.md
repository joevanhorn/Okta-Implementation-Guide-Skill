# Skill Update Bundle — Handoff to Claude Code

Drop-in update for `joevanhorn/Okta-Implementation-Guide-Skill`. All files in
this bundle are production-ready and tested. Tests pass 47/47.

## Bundle contents

```
skill-update/
├── implementation-guide/         # Skill directory (drop in over existing)
│   ├── SKILL.md                  # REVISED — adds Phase 5.5, honest principle
│   ├── assets/
│   │   └── renderer.html         # UNCHANGED — copied from current repo
│   └── references/
│       ├── post-generation-review.md  # NEW — fact-checking review pass
│       ├── url-verification.md         # NEW — URL verification discipline
│       ├── quality-checklist.md        # REVISED — adds Factual Accuracy section
│       ├── document-template.md        # REVISED — replaces minimal template
│       │                                with dark-navy-gradient styled template
│       ├── mermaid-standards.md        # REVISED — de-codifies br vs br/ rule
│       ├── okta-oig-reference.md       # UNCHANGED
│       └── research-protocol.md        # UNCHANGED
├── tests/                        # NEW — validation test suite
│   ├── TEST_PLAN.md
│   ├── run_tests.py              # Test orchestrator
│   ├── test_skill_structure.py
│   ├── test_mermaid_validator.py
│   ├── test_url_patterns.py
│   ├── test_review_fixtures.py
│   ├── test_html_template.py
│   └── fixtures/
│       ├── buggy_implementation_guide.md
│       └── mermaid/
│           ├── good_simple.txt
│           ├── good_with_subgraph.txt
│           ├── bad_unbalanced_brackets.txt
│           ├── bad_subgraph_no_end.txt
│           ├── bad_bullet_char.txt
│           ├── bad_undefined_class.txt
│           └── bad_unused_classdef.txt
└── CHANGES.md                    # This file
```

## Summary of changes

### New files

**`references/post-generation-review.md`** — the fact-checking pass. Required
Phase 5.5 step before delivery. Lists seven high-risk claim categories
(spec URIs, version numbers, count assertions, date-sensitive facts, default
values, UI menu paths, cross-document contradictions). Specifies the
procedure: inventory → classify → verify → surface findings → apply fixes
after acknowledgment. No severity gradient — all factual errors equally
serious. Includes the parallel-section strategy for documents over 3000
lines or 50+ claims.

**`references/url-verification.md`** — URL verification discipline. The
critical anti-pattern: never extrapolate from sibling URLs (with the SAML
vs OIDC counter-example). Domain risk classifications. Known `help.okta.com`
filename patterns and structural anti-patterns table (this table is a
living artifact — add rows when new fabrication patterns are discovered).

### Revised files

**`SKILL.md`** — adds Phase 5.5 (Review) between Assemble and Deliver, with
two sub-passes (5.5.a URL verification, 5.5.b post-generation review). Adds
the "Before Starting" reference table entries for the two new files. Adds
"Honest, not impressive" as a top-level principle (generalizing what was
buried in the OIG reference). Adds the "Verified, not pattern-matched"
principle. Updates direct mode to require one consolidated clarifying
message rather than skipping clarification entirely.

**`references/quality-checklist.md`** — adds a Factual Accuracy section at
the top that references Phase 5.5 outputs. Adds the "verified despite
suspicion" handoff record pattern with example entries. Keeps the existing
structural and mermaid syntax sections.

**`references/document-template.md`** — replaces the minimal HTML template
with the styled template Joe actually ships: dark navy gradient header,
CSS counter section numbering, four callout variants (info / warn / tip /
danger), navigation breadcrumb styling, numbered step list pattern,
discovery items panel, fixed Print/PDF button, full print CSS. Section
templates and discovery item guidance unchanged.

**`references/mermaid-standards.md`** — de-codifies the `<br>` vs `<br/>`
line break rule (it's mermaid-version-dependent and was getting stale).
Replaces with guidance to render-test the current pinned mermaid version
before relying on either form. Rest of the file (color palette, overlap
prevention patterns, common patterns) unchanged.

## Test suite

47 tests across 5 categories. Run with:

```bash
python tests/run_tests.py
```

Categories:

1. **Skill structure** (7 tests) — required files exist, SKILL.md has frontmatter
   and all phases, reference table matches actual files, honest principle present
2. **Mermaid validator** (9 tests) — loads validator from quality-checklist.md
   and exercises each rule against fixtures
3. **URL patterns** (8 tests) — url-verification.md contains required content:
   the rule, anti-extrapolation warning with SAML/OIDC example, domain risk
   table, known anti-pattern rows, verification methods
4. **Review fixtures** (11 tests) — post-generation-review.md declares the
   required categories, procedure steps, severity policy, parallel strategy,
   and verified-despite-suspicion pattern; buggy doc fixture contains
   intentional errors of each category
5. **HTML template** (12 tests) — extracts HTML from document-template.md,
   parses with html.parser, verifies all required structural elements
   (doc-header, callouts, mermaid CDN, print button, CSS counters, etc.)

The test suite has been negatively validated — when SKILL.md or fixtures are
deliberately broken, the relevant tests fail. When restored, all pass.

## Suggested CI setup

Optional but recommended. Add to `.github/workflows/test.yml`:

```yaml
name: Validate Skill
on:
  push:
    branches: [master, main]
  pull_request:

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: python tests/run_tests.py
```

No external dependencies — uses only the Python standard library.

## Open items for Claude Code to consider

1. **README.md update** — the repo's README references the old skill structure.
   Worth updating with a "What's new in this version" section that mentions
   the Phase 5.5 review pass and the URL verification discipline.

2. **`.skill` package build** — if the `build.sh` script in the repo packages
   the skill into a `.skill` zip for distribution, verify it picks up the new
   reference files.

3. **Future platform reference files** — when adding SailPoint, Saviynt, etc.
   reference files (per the README's contributing guide), they will pick up
   the Phase 5.5 review pass automatically without needing skill changes.

4. **Living anti-patterns table** — `url-verification.md` ends with a table of
   known fabrication patterns. Consider adding a contribution note: when new
   patterns are discovered, add a row and a corresponding test case in
   `test_url_patterns.py`.

## What this update deliberately does NOT change

- `references/okta-oig-reference.md` — well-scoped, accurate, no changes needed
- `references/research-protocol.md` — clean, no changes needed
- `assets/renderer.html` — not reviewed in this update; can be revisited separately
- Mermaid v10 CDN pin — not changed; the de-codified line-break rule and
  the new render-test guidance handle version drift more robustly than
  pinning a different version
